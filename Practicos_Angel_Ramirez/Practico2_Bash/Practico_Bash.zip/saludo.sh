if [ "$(tty)" = "/dev/tty1" ]; then
    nombre_completo="Pedro Sanchez"
    echo "¡Hola, $nombre_completo! Bienvenido a la terminal tty1."
fi

