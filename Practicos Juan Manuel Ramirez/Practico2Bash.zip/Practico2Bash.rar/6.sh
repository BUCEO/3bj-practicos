#!/bin/bash

while true; do
    date=$(date +"%Y-%m-%d_%H-%M-%S")
    tar -czf "backup-$date.tar.gz" /home/myusuario
    sleep 300
done
