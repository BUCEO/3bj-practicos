#!/bin/bash

nombre="Juan Manuel Ramirez"

if [ $(tty) == "/dev/tty1" ]; then
    echo "Hola $nombre"
fi
