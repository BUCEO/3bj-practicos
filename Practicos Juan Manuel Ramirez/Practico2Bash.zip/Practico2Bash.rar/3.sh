#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Uso: $0 <argumento>"
    echo "Ejemplo: $0 archivo"
else
    echo "Se esperaban argumentos."
fi
